import os
import psycopg2
import psycopg2.extras
import tabulate
from parser import write_output, UserInput
from dotenv import load_dotenv
from generator import runMain


def query():
    """
    Used for testing standard queries in SQL.
    """
    load_dotenv()

    user = os.getenv('USER')
    password = os.getenv('PASSWORD')
    dbname = os.getenv('DBNAME')

    conn = psycopg2.connect("dbname="+dbname+" user="+user+" password="+password,
                            cursor_factory=psycopg2.extras.DictCursor)
    cur = conn.cursor()
    cur.execute("SELECT * FROM sales WHERE quant > 10")

    return tabulate.tabulate(cur.fetchall(), headers="keys", tablefmt="psql")


def main():
    queries = UserInput()

    for stored_query in queries:
        #print(stored_query)

        runMain(stored_query)
        #print("Parsed dict:")
        #print(stored_query)

        #print("\nGenerated query:")
        #print(write_output(stored_query))


if "__main__" == __name__:
    main()
